<?php
/**
 * Plugin Name:       Keller54 GitHub-Import
 * Description:       Holt neue Versionen (z. B. K-54, K-54 S) automatisch aus GitHub-Releases und veröffentlicht sie im Keller54-Download-Bereich. Benötigt „Keller54 Updates“.
 * Version:           1.1.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Requires Plugins:  keller54-updates
 * Author:            Keller54
 * License:           GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class K54GH {

	const OPT_TOKEN    = 'k54gh_token';
	const OPT_REPOS    = 'k54gh_repos';     // produkt-slug => owner/repo
	const OPT_PREFIXES = 'k54gh_prefixes';  // produkt-slug => Tag-Anfang, z. B. "v" oder "k54s-v"
	const VERSION      = '1.1.0';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
		add_action( 'admin_post_k54gh_save', array( __CLASS__, 'save' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	private static function ready() {
		return class_exists( 'K54U_Storage' ) && method_exists( 'K54U_Storage', 'save_product' );
	}

	public static function repos() {
		$r = get_option( self::OPT_REPOS, false );
		if ( ! is_array( $r ) ) {
			$r = array( 'k54' => 'mfranke76/K54' );
		}
		return $r;
	}

	/**
	 * Tag-Anfang je Produkt. Mehrere Produkte können im selben Repository liegen
	 * (K-54: v1.5.1 · K-54 S: k54s-v1.0.0) – so holt jedes nur seine eigenen Releases.
	 */
	public static function prefix( $slug ) {
		$p = get_option( self::OPT_PREFIXES, array() );
		if ( is_array( $p ) && isset( $p[ $slug ] ) && '' !== $p[ $slug ] ) {
			return $p[ $slug ];
		}
		return 'k54' === $slug ? 'v' : $slug . '-v';
	}

	private static function valid_repo( $repo ) {
		return (bool) preg_match( '#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$#', $repo );
	}

	private static function valid_prefix( $prefix ) {
		return (bool) preg_match( '#^[A-Za-z0-9_.-]{1,40}$#', $prefix );
	}

	public static function has_token() {
		return '' !== (string) get_option( self::OPT_TOKEN, '' );
	}

	// ------------------------------------------------------------ GitHub

	private static function headers( $accept = 'application/vnd.github+json' ) {
		$h = array(
			'Accept'               => $accept,
			'User-Agent'           => 'Keller54-GitHub-Import/' . self::VERSION,
			'X-GitHub-Api-Version' => '2022-11-28',
		);
		$t = (string) get_option( self::OPT_TOKEN, '' );
		if ( '' !== $t ) {
			$h['Authorization'] = 'Bearer ' . $t;
		}
		return $h;
	}

	private static function api( $path ) {
		$res = wp_remote_get( 'https://api.github.com' . $path, array( 'headers' => self::headers(), 'timeout' => 30 ) );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( 200 !== $code ) {
			$msg = is_array( $body ) && isset( $body['message'] ) ? $body['message'] : 'HTTP ' . $code;
			return new WP_Error( 'k54gh', 'GitHub: ' . $msg . ( 404 === $code ? ' – Repository/Version nicht gefunden oder der Schlüssel hat keinen Zugriff.' : '' ) );
		}
		return $body;
	}

	/** Neuestes Release, dessen Tag mit dem Anfang des Produkts beginnt (auch Beta/Vorabversionen). */
	private static function find_release( $repo, $prefix, $tag ) {
		if ( '' !== $tag ) {
			return self::api( '/repos/' . $repo . '/releases/tags/' . rawurlencode( $tag ) );
		}
		$list = self::api( '/repos/' . $repo . '/releases?per_page=50' );
		if ( is_wp_error( $list ) ) {
			return $list;
		}
		$re = '/^' . preg_quote( $prefix, '/' ) . '\d/';
		foreach ( (array) $list as $rel ) {
			if ( empty( $rel['draft'] ) && isset( $rel['tag_name'] ) && preg_match( $re, $rel['tag_name'] ) ) {
				return $rel;
			}
		}
		return new WP_Error( 'k54gh', 'Kein Release mit Tag „' . $prefix . '…“ in ' . $repo . ' gefunden – GitHub baut eventuell noch.' );
	}

	private static function version_of( $tag, $prefix ) {
		$tag = (string) $tag;
		if ( '' !== $prefix && 0 === strpos( $tag, $prefix ) ) {
			return substr( $tag, strlen( $prefix ) );
		}
		return preg_replace( '/^(?:[A-Za-z0-9_.]+-)?[vV]/', '', $tag );
	}

	/** .dmg/.pkg -> mac, .msi (bevorzugt) / .exe -> windows, .AppImage/.deb -> linux */
	private static function platform_for( $name ) {
		$ext = K54U_Storage::ext_of( $name );
		$map = array(
			'dmg'      => array( 'mac', 3 ),
			'pkg'      => array( 'mac', 2 ),
			'msi'      => array( 'windows', 3 ),
			'exe'      => array( 'windows', 2 ),
			'appimage' => array( 'linux', 3 ),
			'deb'      => array( 'linux', 2 ),
		);
		return isset( $map[ $ext ] ) ? $map[ $ext ] : array( '', 0 );
	}

	/** Asset laden: GitHub leitet auf einen signierten Link um, dorthin ohne Schlüssel. */
	private static function download_asset( $api_url, $target ) {
		$res = wp_remote_get( $api_url, array( 'headers' => self::headers( 'application/octet-stream' ), 'timeout' => 60, 'redirection' => 0 ) );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$args = array( 'timeout' => 900, 'stream' => true, 'filename' => $target, 'headers' => array( 'User-Agent' => 'Keller54-GitHub-Import/' . self::VERSION ) );
		$url  = $api_url;
		if ( $code >= 300 && $code < 400 ) {
			$url = wp_remote_retrieve_header( $res, 'location' );
		} elseif ( 200 === $code ) {
			$args['headers'] = self::headers( 'application/octet-stream' );
		} else {
			return new WP_Error( 'k54gh', 'GitHub-Download: HTTP ' . $code );
		}
		$dl = wp_remote_get( $url, $args );
		if ( is_wp_error( $dl ) || 200 !== (int) wp_remote_retrieve_response_code( $dl ) ) {
			wp_delete_file( $target );
			return is_wp_error( $dl ) ? $dl : new WP_Error( 'k54gh', 'Download: HTTP ' . wp_remote_retrieve_response_code( $dl ) );
		}
		return true;
	}

	/**
	 * Release holen und als neue Version des Produkts veröffentlichen.
	 *
	 * @param string $slug Produkt, z. B. k54 oder k54s
	 * @param string $tag  z. B. v1.5.1 oder k54s-v1.0.0; leer = neuestes Release dieses Produkts
	 */
	public static function import( $slug, $tag = '' ) {
		if ( ! self::ready() ) {
			return new WP_Error( 'k54gh', 'Das Plugin „Keller54 Updates“ ist nicht aktiv.' );
		}
		$slug  = sanitize_title( $slug );
		$repos = self::repos();
		$p     = K54U_Storage::product( $slug );
		if ( ! $p ) {
			return new WP_Error( 'k54gh', 'Unbekanntes Produkt: ' . $slug );
		}
		if ( empty( $repos[ $slug ] ) || ! self::valid_repo( $repos[ $slug ] ) ) {
			return new WP_Error( 'k54gh', 'Für ' . $p['name'] . ' ist kein GitHub-Repository eingetragen.' );
		}
		$repo   = $repos[ $slug ];
		$prefix = self::prefix( $slug );
		$rel    = self::find_release( $repo, $prefix, $tag );
		if ( is_wp_error( $rel ) ) {
			return $rel;
		}
		$version = self::version_of( $rel['tag_name'], $prefix );
		if ( ! preg_match( '/^\d+(\.\d+){1,3}$/', $version ) ) {
			return new WP_Error( 'k54gh', 'Der Tag „' . $rel['tag_name'] . '“ ist keine Versionsnummer.' );
		}

		$pick = array();
		foreach ( (array) $rel['assets'] as $a ) {
			list( $pf, $prio ) = self::platform_for( $a['name'] );
			if ( $pf && ( ! isset( $pick[ $pf ] ) || $prio > $pick[ $pf ][1] ) ) {
				$pick[ $pf ] = array( $a, $prio );
			}
		}
		if ( ! $pick ) {
			return new WP_Error( 'k54gh', 'Im Release ' . $rel['tag_name'] . ' liegt noch kein Installer – GitHub baut eventuell noch.' );
		}

		K54U_Storage::activate();
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 1200 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		$now    = current_time( 'mysql' );
		$old    = array();
		$result = array();
		foreach ( $pick as $pf => $x ) {
			$a    = $x[0];
			$ext  = K54U_Storage::ext_of( $a['name'] );
			$name = $slug . '-' . $version . '-' . $pf . '-' . wp_generate_password( 16, false ) . '.' . $ext;
			$path = K54U_Storage::dir() . '/' . $name;
			$ok   = self::download_asset( $a['url'], $path );
			if ( is_wp_error( $ok ) ) {
				$result[ $pf ] = 'Fehler: ' . $ok->get_error_message();
				continue;
			}
			$size = (int) filesize( $path );
			if ( ! empty( $a['size'] ) && (int) $a['size'] !== $size ) {
				wp_delete_file( $path );
				$result[ $pf ] = 'Fehler: Datei unvollständig angekommen';
				continue;
			}
			if ( ! empty( $p['files'][ $pf ]['file'] ) ) {
				$old[] = $p['files'][ $pf ]['file'];
			}
			$p['files'][ $pf ] = array(
				'file'    => $name,
				'size'    => $size,
				'sha256'  => hash_file( 'sha256', $path ),
				'version' => $version,
				'date'    => $now,
			);
			$result[ $pf ] = $a['name'] . ' (' . size_format( $size ) . ')';
		}
		if ( ! array_filter( $result, function ( $r ) { return 0 !== strpos( $r, 'Fehler' ); } ) ) {
			return new WP_Error( 'k54gh', implode( ' · ', $result ) );
		}
		$p['version'] = $version;
		$p['date']    = $now;
		if ( ! empty( $rel['body'] ) ) {
			$p['notes'] = sanitize_textarea_field( (string) $rel['body'] );
		}
		K54U_Storage::save_product( $slug, $p );
		foreach ( $old as $f ) {
			if ( ! K54U_Storage::file_in_use( $f ) ) {
				wp_delete_file( K54U_Storage::dir() . '/' . basename( $f ) );
			}
		}
		return array( 'product' => $slug, 'name' => $p['name'], 'version' => $version, 'tag' => $rel['tag_name'], 'beta' => ! empty( $rel['prerelease'] ), 'platforms' => $result );
	}

	/** Neues Produkt anlegen (falls es noch nicht existiert) und Repository/Tag-Anfang merken. */
	public static function ensure_product( $slug, $name, $category, $description, $repo, $prefix ) {
		$slug = sanitize_title( $slug );
		if ( '' === $slug ) {
			return new WP_Error( 'k54gh', 'Produkt fehlt.' );
		}
		if ( ! K54U_Storage::product( $slug ) ) {
			if ( '' === $name ) {
				return new WP_Error( 'k54gh', 'Unbekanntes Produkt: ' . $slug . ' (zum Anlegen bitte „name“ mitgeben).' );
			}
			$cats = K54U_Storage::categories();
			K54U_Storage::save_product(
				$slug,
				array(
					'name'        => $name,
					'category'    => in_array( $category, $cats, true ) ? $category : ( $cats ? $cats[0] : '' ),
					'description' => $description,
					'files'       => array(),
				)
			);
		}
		if ( '' !== $repo && self::valid_repo( $repo ) ) {
			$repos          = self::repos();
			$repos[ $slug ] = $repo;
			update_option( self::OPT_REPOS, $repos, false );
		}
		if ( '' !== $prefix && self::valid_prefix( $prefix ) ) {
			$pre          = get_option( self::OPT_PREFIXES, array() );
			$pre          = is_array( $pre ) ? $pre : array();
			$pre[ $slug ] = $prefix;
			update_option( self::OPT_PREFIXES, $pre, false );
		}
		return true;
	}

	// ------------------------------------------------------------ REST (nur Admins)

	public static function routes() {
		$admin = function () {
			return current_user_can( 'manage_options' );
		};
		register_rest_route(
			'k54/v1',
			'/admin/import',
			array(
				'methods'             => 'POST',
				'permission_callback' => $admin,
				'callback'            => function ( WP_REST_Request $req ) {
					$slug = (string) $req->get_param( 'product' );
					$slug = '' !== $slug ? sanitize_title( $slug ) : 'k54';
					$t    = function ( $k ) use ( $req ) {
						return trim( sanitize_text_field( (string) $req->get_param( $k ) ) );
					};
					if ( '' !== $t( 'name' ) || '' !== $t( 'repo' ) || '' !== $t( 'prefix' ) ) {
						$ok = self::ensure_product( $slug, $t( 'name' ), $t( 'category' ), $t( 'description' ), $t( 'repo' ), $t( 'prefix' ) );
						if ( is_wp_error( $ok ) ) {
							return $ok;
						}
					}
					$r = self::import( $slug, $t( 'tag' ) );
					return is_wp_error( $r ) ? $r : rest_ensure_response( $r );
				},
			)
		);
		register_rest_route(
			'k54/v1',
			'/admin/status',
			array(
				'methods'             => 'GET',
				'permission_callback' => $admin,
				'callback'            => function () {
					$out = array( 'version' => self::VERSION, 'github_token' => self::has_token(), 'repos' => self::repos(), 'prefixes' => array(), 'products' => array() );
					if ( self::ready() ) {
						foreach ( K54U_Storage::products() as $slug => $p ) {
							$out['prefixes'][ $slug ] = self::prefix( $slug );
							$files = array();
							foreach ( $p['files'] as $pf => $f ) {
								$files[ $pf ] = array( 'version' => $f['version'], 'size' => $f['size'], 'present' => '' !== K54U_Storage::file_path( $slug, $pf ) );
							}
							$out['products'][ $slug ] = array( 'name' => $p['name'], 'version' => $p['version'], 'files' => $files );
						}
					}
					return rest_ensure_response( $out );
				},
			)
		);
	}

	// ------------------------------------------------------------ Verwaltung

	public static function menu() {
		if ( isset( $GLOBALS['admin_page_hooks']['k54u'] ) ) {
			add_submenu_page( 'k54u', 'GitHub-Import', 'GitHub-Import', 'manage_options', 'k54gh', array( __CLASS__, 'page' ) );
		} else {
			add_management_page( 'Keller54 GitHub-Import', 'Keller54 GitHub', 'manage_options', 'k54gh', array( __CLASS__, 'page' ) );
		}
	}

	private static function back( $msg ) {
		wp_safe_redirect( add_query_arg( array( 'page' => 'k54gh', 'k54gh_msg' => rawurlencode( $msg ) ), admin_url( isset( $GLOBALS['admin_page_hooks']['k54u'] ) ? 'admin.php' : 'tools.php' ) ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$msg   = isset( $_GET['k54gh_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['k54gh_msg'] ) ) : '';
		$repos = self::repos();
		?>
		<div class="wrap">
			<h1>GitHub-Import</h1>
			<?php if ( $msg ) : ?><div class="notice notice-info is-dismissible"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
			<?php if ( ! self::ready() ) : ?><div class="notice notice-error"><p>Bitte zuerst „Keller54 Updates“ aktivieren.</p></div><?php return; endif; ?>
			<p>Neue Versionen werden auf GitHub gebaut und hier mit einem Klick (oder automatisch durch Claude) für alle Mitglieder veröffentlicht.
			Liegen mehrere Produkte im selben Repository, unterscheidet der <strong>Tag-Anfang</strong> sie (z. B. K-54: <code>v</code>, K-54 S: <code>k54s-v</code>).</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="k54gh_save">
				<?php wp_nonce_field( 'k54gh' ); ?>
				<table class="form-table" role="presentation">
					<tr><th><label for="k54gh_token">GitHub-Schlüssel</label></th>
						<td><input id="k54gh_token" name="token" type="password" class="regular-text" autocomplete="off"
							placeholder="<?php echo self::has_token() ? '•••••••• gespeichert – leer lassen zum Behalten' : 'github_pat_…'; ?>">
						<p class="description">Fine-grained Token mit <em>Contents: Read-only</em>, nur für deine Software-Repositories. Wird nie angezeigt.</p>
						<?php if ( self::has_token() ) : ?><label><input type="checkbox" name="token_delete" value="1"> Schlüssel löschen</label><?php endif; ?></td></tr>
					<?php foreach ( K54U_Storage::products() as $slug => $p ) : ?>
					<tr><th><?php echo esc_html( $p['name'] ); ?> <span class="description">(<?php echo esc_html( $p['version'] ? $p['version'] : '—' ); ?>)</span></th>
						<td><input name="repo[<?php echo esc_attr( $slug ); ?>]" type="text" class="regular-text" value="<?php echo esc_attr( isset( $repos[ $slug ] ) ? $repos[ $slug ] : '' ); ?>" placeholder="owner/repo – leer = kein GitHub">
						<input name="prefix[<?php echo esc_attr( $slug ); ?>]" type="text" class="small-text" style="width:7em" value="<?php echo esc_attr( self::prefix( $slug ) ); ?>" title="Tag-Anfang">
						<button class="button" name="import" value="<?php echo esc_attr( $slug ); ?>">Neueste Version holen</button></td></tr>
					<?php endforeach; ?>
				</table>
				<?php submit_button( 'Speichern' ); ?>
			</form>
		</div>
		<?php
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Keine Berechtigung.' );
		}
		check_admin_referer( 'k54gh' );
		$tok = isset( $_POST['token'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['token'] ) ) ) : '';
		if ( ! empty( $_POST['token_delete'] ) ) {
			delete_option( self::OPT_TOKEN );
		} elseif ( '' !== $tok ) {
			update_option( self::OPT_TOKEN, $tok, false );
		}
		$repos = array();
		if ( isset( $_POST['repo'] ) && is_array( $_POST['repo'] ) ) {
			foreach ( wp_unslash( $_POST['repo'] ) as $slug => $repo ) {
				$repo = trim( sanitize_text_field( $repo ) );
				if ( self::valid_repo( $repo ) ) {
					$repos[ sanitize_title( $slug ) ] = $repo;
				}
			}
		}
		update_option( self::OPT_REPOS, $repos, false );
		$pre = array();
		if ( isset( $_POST['prefix'] ) && is_array( $_POST['prefix'] ) ) {
			foreach ( wp_unslash( $_POST['prefix'] ) as $slug => $prefix ) {
				$prefix = trim( sanitize_text_field( $prefix ) );
				if ( self::valid_prefix( $prefix ) ) {
					$pre[ sanitize_title( $slug ) ] = $prefix;
				}
			}
		}
		update_option( self::OPT_PREFIXES, $pre, false );

		if ( ! empty( $_POST['import'] ) ) {
			$r = self::import( sanitize_title( wp_unslash( $_POST['import'] ) ) );
			if ( is_wp_error( $r ) ) {
				self::back( $r->get_error_message() );
			}
			$parts = array();
			foreach ( $r['platforms'] as $pf => $t ) {
				$parts[] = $pf . ': ' . $t;
			}
			self::back( $r['name'] . ' ' . $r['version'] . ( $r['beta'] ? ' (Beta)' : '' ) . ' veröffentlicht – ' . implode( ' · ', $parts ) );
		}
		self::back( 'Gespeichert.' );
	}
}

K54GH::init();
